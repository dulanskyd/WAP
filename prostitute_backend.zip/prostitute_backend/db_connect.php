<?php
    $connect = mysqli_connect("localhost", "root", "", "hnizdecko");
    if (mysqli_connect_errno()) {
        exit('ups');
    }
?>